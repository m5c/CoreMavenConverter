package org.mt4j.util.font;

public interface ITextureFontCharacter {
	
	public void setTextureFiltered(boolean filtered);

}
