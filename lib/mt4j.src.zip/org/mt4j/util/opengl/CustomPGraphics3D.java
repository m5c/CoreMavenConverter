package org.mt4j.util.opengl;

import processing.opengl.PGraphicsOpenGL;

public class CustomPGraphics3D extends PGraphicsOpenGL {
    
    @Override
    protected void allocate() {
        // TODO Auto-generated method stub
        super.allocate();
        
        smooth(8);
    }

}
