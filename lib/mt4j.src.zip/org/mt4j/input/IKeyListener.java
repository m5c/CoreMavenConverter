package org.mt4j.input;

public interface IKeyListener{
	
	public void keyPressed(char key, int keyCode);
	
	public void keyRleased(char key, int keyCode);
	
}
